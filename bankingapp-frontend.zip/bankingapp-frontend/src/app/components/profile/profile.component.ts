import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TokenStorageService } from 'src/app/services/token-storage.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  email = this.tokenService.getUser().email;
  firstname = this.tokenService.getUser().firstname;
  lastname = this.tokenService.getUser().lastname;
  phonenumber = this.tokenService.getUser().phonenumber;
  content?:string;

  form: any = {
    email:this.email,
    firstname: this.firstname,
    lastname: this.lastname,
    phonenumber: this.phonenumber
  }
  // Placeholders for myInfo variables, to be swapped out for database references
  // firstName: string = "Charles";
  // lastName: string = "Dickens";
  // email: string = "dude@myguy.org";


  constructor(private userService: UserService, private router: Router, private tokenService: TokenStorageService) { }

  ngOnInit(): void {
    document.getElementById("edit-Info")!.style.display = "none";
    console.log(this.form);
  }

  
  edit(){
    this.router.navigateByUrl('/user/:id/edit');
  }
  depositwithdraw(){
    this.router.navigateByUrl('/deposit-withdraw');
  }
  transfer(){
  this.router.navigateByUrl('/transfer');
  }
  accounts(){
    this.router.navigateByUrl('/accounts');
      }
 
  close(){
    document.getElementById("edit-Info")!.style.display = "none";
    document.getElementById("myInfo")!.style.filter = "blur(0px)"; //blur will blur the background content to make it look nicer

  }

  update(){
    const{firstname, lastname, email, phonenumber} = this.form;
    this.userService.changeProfileSettings(email, firstname, lastname, phonenumber).subscribe(
      data => {
        this.content = data;
        console.log(data);
      },
      err => {
        this.content = JSON.parse(err.error).message;
        console.log("in the error");
      }
    );
    document.getElementById("edit-Info")!.style.display = "none";
    document.getElementById("myInfo")!.style.filter = "blur(0px)"; //blur will blur the background content to make it look nicer
  }

}
