import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../models/user';
const API_URL = 'http://localhost:8085/api/test/';
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable({
  providedIn: 'root'
})
export class UserService {
  tokenStorageService: any;
  find(id: number) {
    throw new Error('Method not implemented.');
  }
  changeUsername(username: any) {
    throw new Error('Method not implemented.');
  }
  constructor(private http: HttpClient) { }
  getPublicContent(): Observable<any> {
    return this.http.get(API_URL + 'all', { responseType: 'text' });
  }
  getUserBoard(): Observable<any> {
    return this.http.get(API_URL + 'user', { responseType: 'text' });
  }
  getAdminBoard(): Observable<any> {
    return this.http.get(API_URL + 'admin', { responseType: 'text' });
  }
  getAll(): Observable<User[]> {
    return this.http.get<User[]>(API_URL);
  }
  get(id: any): Observable<Object> {
    return this.http.get(`${API_URL}/${id}`);
  }
  create(data: any): Observable<any> {
    return this.http.post(API_URL, data);
  }
  update(id: any, data: any): Observable<any> {
    return this.http.put(`${API_URL}/${id}`, data);
  }
  delete(id: any): Observable<any> {
    return this.http.delete(`${API_URL}/${id}`);
  }
  deleteAll(): Observable<any> {
    return this.http.delete(API_URL);
  }
  

  changeProfileSettings(firstname: string, lastname: string, email: string, username?: string): Observable<any> {

    console.log(this.tokenStorageService.getToken());
    console.log(this.tokenStorageService.getUser());
    username = this.tokenStorageService.getUser().username

    return this.http.put(API_URL + 'changeProfileSettings',
    {
      firstname,
      lastname,
      email,
      username,
    },httpOptions);
  

  }

}